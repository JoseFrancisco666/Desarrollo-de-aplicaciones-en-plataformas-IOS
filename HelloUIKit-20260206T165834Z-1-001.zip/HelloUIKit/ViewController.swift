import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var messageButton: UILabel!
    @IBOutlet weak var Name: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("View controller code")
        
        Name.text = "Jose Francisco Carrillo Chavez"
    }
    
    @IBAction func modifyMessageButton(_ sender: UIButton) {
        print("Button tapped")
        
        messageButton.text = """
        • Certificate in Big Data on AWS
        • Certificate in Android Web Application Development
        • Certificate in Java Programming
        """
    }
}
